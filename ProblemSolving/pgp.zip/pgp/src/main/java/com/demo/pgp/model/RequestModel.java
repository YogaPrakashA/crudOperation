package com.demo.pgp.model;

import lombok.Data;

@Data
public class RequestModel {

	private String url;
	private String privateKey;
}
