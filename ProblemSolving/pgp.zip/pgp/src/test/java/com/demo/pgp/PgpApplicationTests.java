package com.demo.pgp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PgpApplicationTests {

	@Test
	void contextLoads() {
	}

}
